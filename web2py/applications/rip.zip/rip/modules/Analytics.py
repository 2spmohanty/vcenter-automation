__author__ = 'smrutim'

import requests
import json



def PostVpxData():
    URI = "https://vcsa.vmware.com/ph-stg/api/hyper/send?_c=cpbu_vcst_vac_staging.v0&_i=RIP_STAGING_DATA"


def PostHeapAnalysisDate():
    pass


def PostMemoryLeakData():
    pass