# This module contains globals for test-vpx.

# Global for the --standalone option
standaloneMode = False
extra_test_args = {}